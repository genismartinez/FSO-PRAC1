# FSOPrac1-shell script
Execute 'Prac1.sh' by running the following commands first:<br/>
  1-"chmod 777 Prac1.sh"<br/>
  2-"./Prac1.sh" followed by the parameters wanted (read documentation attatched at the end of the project)
  
[Enunciat_P1-1_v4.pdf](https://github.com/carlosmgv02/FSOPrac1/files/8201308/Enunciat_P1-1_v4.pdf)
